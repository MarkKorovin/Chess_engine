A1 = int('A') - int('0')
print (A1)
