WHITE_PAWN_1 = 'A'+'2'
print (WHITE_PAWN_1)
        
