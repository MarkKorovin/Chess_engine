class Empty(object):
    def __init__(self):
        self
