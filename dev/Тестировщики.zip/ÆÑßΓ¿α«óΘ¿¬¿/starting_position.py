def STARTING_POSITION (START):
    if (START == 1):
        A1 = 'WHITE_ROOK'
        B1 = 'WHITE_KNIGHT'
        C1 = 'WHITE_BISHOP'
        D1 = 'WHITE_QUEEN'
        E1 = 'WHITE_KING'
        F1 = '
        
        
