def CELL(LETTER, NUMBER):
    if (LETTER == 'A' and NUMBER == '1'):
        PIECE_IN_CELL_A1 = 'WHITE_ROOK'
        piece = 'WHITE_ROOK'
        
    if (LETTER == 'A' and NUMBER == '2'):
        PIECE_IN_CELL_A2 = 'WHITE_PAWN'
        piece = 'WHITE_PAWN'
        
    if (LETTER == 'A' and NUMBER == '3'):
        PIECE_IN_CELL_A3 = 'NO_PIECE'
        piece = 'NO_PIECE'
        
    if (LETTER == 'A' and NUMBER == '4'):
        PIECE_IN_CELL_A4 = 'NO_PIECE'
        piece = 'NO_PIECE'
        
    if (LETTER == 'A' and NUMBER == '5'):
        PIECE_IN_CELL_A5 = 'NO_PIECE'
        piece = 'NO_PIECE'
        
    if (LETTER == 'A' and NUMBER == '6'):
        PIECE_IN_CELL_A6 = 'NO_PIECE'
        piece = 'NO_PIECE'
        
    if (LETTER == 'A' and NUMBER == '7'):
        PIECE_IN_CELL_A7 = 'BLACK_PAWN'
        piece = 'BLACK_PAWN'
        
    if (LETTER == 'A' and NUMBER == '8'):
        PIECE_IN_CELL_A8 = 'BLACK_ROOK'
        piece = 'BLACK_ROOK'

        
        
    if (LETTER == 'B' and NUMBER == '1'):
        PIECE_IN_CELL_B1 = 'WHITE_KNIGHT'
        piece = 'WHITE_KNIGHT'
        
    if (LETTER == 'B' and NUMBER == '2'):
        PIECE_IN_CELL_B2 = 'WHITE_PAWN'
        piece = 'WHITE_PAWN'
        
    if (LETTER == 'B' and NUMBER == '3'):
        PIECE_IN_CELL_B3 = 'NO_PIECE'
        piece = 'NO_PIECE'
        
    if (LETTER == 'B' and NUMBER == '4'):
        PIECE_IN_CELL_B4 = 'NO_PIECE'
        piece = 'NO_PIECE'
        
    if (LETTER == 'B' and NUMBER == '5'):
        PIECE_IN_CELL_B5 = 'NO_PIECE'
        piece = 'NO_PIECE'
        
    if (LETTER == 'B' and NUMBER == '6'):
        PIECE_IN_CELL_B6 = 'NO_PIECE'
        piece = 'NO_PIECE'
        
    if (LETTER == 'B' and NUMBER == '7'):
        PIECE_IN_CELL_B7 = 'BLACK_PAWN'
        piece = 'BLACK_PAWN'
        
    if (LETTER == 'B' and NUMBER == '8'):
        PIECE_IN_CELL_B8 = 'BLACK_KNIGHT'
        piece = 'BLACK_KNIGHT'



    if (LETTER == 'C' and NUMBER == '1'):
        PIECE_IN_CELL_C1 = 'WHITE_BISHOP'
        piece = 'WHITE_BISHOP'
        
    if (LETTER == 'C' and NUMBER == '2'):
        PIECE_IN_CELL_C2 = 'WHITE_PAWN'
        piece = 'WHITE_PAWN'
        
    if (LETTER == 'C' and NUMBER == '3'):
        PIECE_IN_CELL_C3 = 'NO_PIECE'
        piece = 'NO_PIECE'
        
    if (LETTER == 'C' and NUMBER == '4'):
        PIECE_IN_CELL_C4 = 'NO_PIECE'
        piece = 'NO_PIECE'
        
    if (LETTER == 'C' and NUMBER == '5'):
        PIECE_IN_CELL_C5 = 'NO_PIECE'
        piece = 'NO_PIECE'
        
    if (LETTER == 'C' and NUMBER == '6'):
        PIECE_IN_CELL_C6 = 'NO_PIECE'
        piece = 'NO_PIECE'
        
    if (LETTER == 'C' and NUMBER == '7'):
        PIECE_IN_CELL_C7 = 'BLACK_PAWN'
        piece = 'BLACK_PAWN'
        
    if (LETTER == 'C' and NUMBER == '8'):
        PIECE_IN_CELL_C8 = 'BLACK_BISHOP'
        piece = 'BLACK_BISHOP'



    if (LETTER == 'D' and NUMBER == '1'):
        PIECE_IN_CELL_D1 = 'WHITE_QUEEN'
        piece = 'WHITE_QUEEN'
        
    if (LETTER == 'D' and NUMBER == '2'):
        PIECE_IN_CELL_D2 = 'WHITE_PAWN'
        piece = 'WHITE_PAWN'
        
    if (LETTER == 'D' and NUMBER == '3'):
        PIECE_IN_CELL_D3 = 'NO_PIECE'
        piece = 'NO_PIECE'
        
    if (LETTER == 'D' and NUMBER == '4'):
        PIECE_IN_CELL_D4 = 'NO_PIECE'
        piece = 'NO_PIECE'
        
    if (LETTER == 'D' and NUMBER == '5'):
        PIECE_IN_CELL_D5 = 'NO_PIECE'
        piece = 'NO_PIECE'
        
    if (LETTER == 'D' and NUMBER == '6'):
        PIECE_IN_CELL_D6 = 'NO_PIECE'
        piece = 'NO_PIECE'
        
    if (LETTER == 'D' and NUMBER == '7'):
        PIECE_IN_CELL_D7 = 'BLACK_PAWN'
        piece = 'BLACK_PAWN'
        
    if (LETTER == 'D' and NUMBER == '8'):
        PIECE_IN_CELL_D8 = 'BLACK_QUEEN'
        piece = 'BLACK_QUEEN'



    if (LETTER == 'E' and NUMBER == '1'):
        PIECE_IN_CELL_E1 = 'WHITE_KING'
        piece = 'WHITE_KING'
        
    if (LETTER == 'E' and NUMBER == '2'):
        PIECE_IN_CELL_E2 = 'WHITE_PAWN'
        piece = 'WHITE_PAWN'
        
    if (LETTER == 'E' and NUMBER == '3'):
        PIECE_IN_CELL_E3 = 'NO_PIECE'
        piece = 'NO_PIECE'
        
    if (LETTER == 'E' and NUMBER == '4'):
        PIECE_IN_CELL_E4 = 'NO_PIECE'
        piece = 'NO_PIECE'
        
    if (LETTER == 'E' and NUMBER == '5'):
        PIECE_IN_CELL_E5 = 'NO_PIECE'
        piece = 'NO_PIECE'
        
    if (LETTER == 'E' and NUMBER == '6'):
        PIECE_IN_CELL_E6 = 'NO_PIECE'
        piece = 'NO_PIECE'
        
    if (LETTER == 'E' and NUMBER == '7'):
        PIECE_IN_CELL_E7 = 'BLACK_PAWN'
        piece = 'BLACK_PAWN'
        
    if (LETTER == 'E' and NUMBER == '8'):
        PIECE_IN_CELL_E8 = 'BLACK_KING'
        piece = 'BLACK_KING'

        

    if (LETTER == 'F' and NUMBER == '1'):
        PIECE_IN_CELL_F1 = 'WHITE_BISHOP'
        piece = 'WHITE_BISHOP'
        
    if (LETTER == 'F' and NUMBER == '2'):
        PIECE_IN_CELL_F2 = 'WHITE_PAWN'
        piece = 'WHITE_PAWN'
        
    if (LETTER == 'F' and NUMBER == '3'):
        PIECE_IN_CELL_F3 = 'NO_PIECE'
        piece = 'NO_PIECE'
        
    if (LETTER == 'F' and NUMBER == '4'):
        PIECE_IN_CELL_F4 = 'NO_PIECE'
        piece = 'NO_PIECE'
        
    if (LETTER == 'F' and NUMBER == '5'):
        PIECE_IN_CELL_F5 = 'NO_PIECE'
        piece = 'NO_PIECE'
        
    if (LETTER == 'F' and NUMBER == '6'):
        PIECE_IN_CELL_F6 = 'NO_PIECE'
        piece = 'NO_PIECE'
        
    if (LETTER == 'F' and NUMBER == '7'):
        PIECE_IN_CELL_F7 = 'BLACK_PAWN'
        piece = 'BLACK_PAWN'
        
    if (LETTER == 'F' and NUMBER == '8'):
        PIECE_IN_CELL_F8 = 'BLACK_BISHOP'
        piece = 'BLACK_BISHOP'




    if (LETTER == 'G' and NUMBER == '1'):
        PIECE_IN_CELL_G1 = 'WHITE_KNIGHT'
        piece = 'WHITE_KNIGHT'
        
    if (LETTER == 'G' and NUMBER == '2'):
        PIECE_IN_CELL_G2 = 'WHITE_PAWN'
        piece = 'WHITE_PAWN'
        
    if (LETTER == 'G' and NUMBER == '3'):
        PIECE_IN_CELL_G3 = 'NO_PIECE'
        piece = 'NO_PIECE'
        
    if (LETTER == 'G' and NUMBER == '4'):
        PIECE_IN_CELL_G4 = 'NO_PIECE'
        piece = 'NO_PIECE'
        
    if (LETTER == 'G' and NUMBER == '5'):
        PIECE_IN_CELL_G5 = 'NO_PIECE'
        piece = 'NO_PIECE'
        
    if (LETTER == 'G' and NUMBER == '6'):
        PIECE_IN_CELL_G6 = 'NO_PIECE'
        piece = 'NO_PIECE'
        
    if (LETTER == 'G' and NUMBER == '7'):
        PIECE_IN_CELL_G7 = 'BLACK_PAWN'
        piece = 'BLACK_PAWN'
        
    if (LETTER == 'G' and NUMBER == '8'):
        PIECE_IN_CELL_G8 = 'BLACK_KNIGHT'
        piece = 'BLACK_KNIGHT'



    if (LETTER == 'H' and NUMBER == '1'):
        PIECE_IN_CELL_H1 = 'WHITE_ROOK'
        piece = 'WHITE_ROOK'
        
    if (LETTER == 'H' and NUMBER == '2'):
        PIECE_IN_CELL_H2 = 'WHITE_PAWN'
        piece = 'WHITE_PAWN'
        
    if (LETTER == 'H' and NUMBER == '3'):
        PIECE_IN_CELL_H3 = 'NO_PIECE'
        piece = 'NO_PIECE'
        
    if (LETTER == 'H' and NUMBER == '4'):
        PIECE_IN_CELL_H4 = 'NO_PIECE'
        piece = 'NO_PIECE'
        
    if (LETTER == 'H' and NUMBER == '5'):
        PIECE_IN_CELL_H5 = 'NO_PIECE'
        piece = 'NO_PIECE'
        
    if (LETTER == 'H' and NUMBER == '6'):
        PIECE_IN_CELL_H6 = 'NO_PIECE'
        piece = 'NO_PIECE'
        
    if (LETTER == 'H' and NUMBER == '7'):
        PIECE_IN_CELL_H7 = 'BLACK_PAWN'
        piece = 'BLACK_PAWN'
        
    if (LETTER == 'H' and NUMBER == '8'):
        PIECE_IN_CELL_H8 = 'BLACK_ROOK'
        piece = 'BLACK_ROOK'
        
    return piece

'''
ДЛЯ ОТЛАДКИ
n=0
while (True):
    LETTER = input(' ')
    NUMBER = input(' ')
    piece = CELL(LETTER, NUMBER)
    if (piece == 'NO_PIECE'):
        print ('NONE')
    else:
        print(piece)
    '''


