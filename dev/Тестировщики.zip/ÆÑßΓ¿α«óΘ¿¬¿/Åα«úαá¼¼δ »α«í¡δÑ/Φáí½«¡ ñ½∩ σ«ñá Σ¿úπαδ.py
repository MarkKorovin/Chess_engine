def PIECE_MOVES (PIECE):
    if (PIECE == 'BLACK_PAWN' or PIECE == 'WHITE_PAWN'):
        

        
    if (PIECE == 'BLACK_KNIGHT' or PIECE == 'WHITE_KNIGHT'):



            
    if (PIECE == 'BLACK_BISHOP' or PIECE == 'WHITE_BISHOP'):



            
    if (PIECE == 'BLACK_ROOK' or PIECE == 'WHITE_ROOK'):



            
    if (PIECE == 'BLACK_QUEEN' or PIECE == 'WHITE_QUEEN'):

                      

    if (PIECE == 'BLACK_KING' or PIECE == 'WHITE_KING'):

