def func():
    a = 0
    return print (a)
func
